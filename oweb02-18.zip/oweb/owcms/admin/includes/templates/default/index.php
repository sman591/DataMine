<?php $user->admin_check('page_head'); ?>
<div class="page-head">
<h1><? echo ADMIN_TITLE; ?></h1>
</div>
<hr />
<div class="well">
Welcome back! Links above.
</div>