tinyMCE.addI18n('sk.codemagic',{
    code_title: "CodeMagic - zvýraznenie syntaxe a formátovanie kódu",
    code_label: "Editovať kód",
    toggle_highlighting: "Zvýraznenie kódu",
    toggle_autocompletion: "Doplňovenie kódu",
    search: "Hľadať",
    replace: "Nahradiť",
    undo: "Späť",
    redo: "Opakovať",
    search_replace: "Hľadať a nahradiť",
    reintendt: "Sformátovať kód",
    nothing_found: "Hľadaný výraz nebol nájdený.",
    nothing_to_replace: "Nie je čo nahradiť."
});