<?php

/*	Olivera Web CMS
	Site: oWeb Media
	URL: http://media.oweb.co
	Date: Summer 2012
	
	Lead Dev: Stuart Olivera
	Contact: stuart@oliveraweb.com
*/

require_once('../../header.php');

$page = new owcms_page();

$page->initialize();

?>