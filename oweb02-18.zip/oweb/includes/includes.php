<?php 

/*	Olivera Web CMS

	 -- includes.php --
	 
	 Site-specific includes to include

*/

require_once 'templates/owmedia/functions.php';

require_once 'classes/mail/sendMail.php';

require_once 'classes/bootstrap/grid.php';
require_once 'classes/bootstrap/collapse.php';
require_once 'classes/bootstrap/alerts.php';

require_once 'classes/jquery_file/form.php';

?>