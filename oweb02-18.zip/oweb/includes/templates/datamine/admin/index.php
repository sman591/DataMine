<?php $user->admin_check('page_head'); ?>
<div class="page-head">
<h1>Admin</h1>
</div>