<?php echo stripslashes( $this->content() ); ?>

<script type="text/javascript">
function custom_pageLoad() {
	
}
</script>