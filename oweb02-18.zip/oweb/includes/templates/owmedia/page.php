<div class="page-header">
	<h1><? echo stripslashes($this->details('name')); ?></h1>
</div>

<?php echo stripslashes( $this->content() ); ?>

<script type="text/javascript">
function custom_pageLoad() {
	
}
</script>