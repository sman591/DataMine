<?php

$_SERVER['DOCUMENT_ROOT'] = $_SERVER['DOCUMENT_ROOT'].'/';

/*	Olivera Web CMS */

require_once('owcms/includes/header.php');

$page = new owcms_page();

$page->initialize();

?>